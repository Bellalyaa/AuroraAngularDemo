import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-ranking',
  templateUrl: './content-ranking.component.html',
  styleUrls: ['./content-ranking.component.less']
})
export class ContentRankingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
