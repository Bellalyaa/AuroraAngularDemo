import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-form',
  templateUrl: './content-form.component.html',
  styleUrls: ['./content-form.component.less']
})
export class ContentFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
