import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-article-list',
  templateUrl: './home-article-list.component.html',
  styleUrls: ['./home-article-list.component.less']
})
export class HomeArticleListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
