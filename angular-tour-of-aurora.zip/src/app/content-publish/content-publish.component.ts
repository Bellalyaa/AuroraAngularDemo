import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-publish',
  templateUrl: './content-publish.component.html',
  styleUrls: ['./content-publish.component.less']
})
export class ContentPublishComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
