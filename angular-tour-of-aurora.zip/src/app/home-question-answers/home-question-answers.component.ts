import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-question-answers',
  templateUrl: './home-question-answers.component.html',
  styleUrls: ['./home-question-answers.component.less']
})
export class HomeQuestionAnswersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
