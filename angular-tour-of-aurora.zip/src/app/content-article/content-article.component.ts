import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-article',
  templateUrl: './content-article.component.html',
  styleUrls: ['./content-article.component.less']
})
export class ContentArticleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
