import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-rotation',
  templateUrl: './home-rotation.component.html',
  styleUrls: ['./home-rotation.component.less']
})
export class HomeRotationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
