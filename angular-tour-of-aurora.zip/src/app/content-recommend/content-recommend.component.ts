import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-recommend',
  templateUrl: './content-recommend.component.html',
  styleUrls: ['./content-recommend.component.less']
})
export class ContentRecommendComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
